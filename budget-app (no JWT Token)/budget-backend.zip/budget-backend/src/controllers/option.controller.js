const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// ✅ Obtener solo las opciones activas
const getActiveOptions = async (req, res) => {
  try {
    const options = await prisma.option.findMany({
      where: { active: true },
      include: {
        category: true
      }
    });
    res.json(options);
  } catch (error) {
    console.error('Error al obtener opciones activas:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};

// ✅ Crear una nueva opción
const createOption = async (req, res) => {
  try {
    const { name, priceEuro, hours, description, active, categoryId } = req.body;

    const newOption = await prisma.option.create({
      data: {
        name,
        priceEuro,
        hours,
        description,
        active,
        category: {
          connect: { id: categoryId },
        },
      },
    });

    res.status(201).json(newOption);
  } catch (error) {
    console.error('Error al crear opción:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};

// ✅ Actualizar una opción
const updateOption = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, priceEuro, hours, description, active, categoryId } = req.body;

    const updatedOption = await prisma.option.update({
      where: { id: parseInt(id) },
      data: {
        name,
        priceEuro,
        hours,
        description,
        active,
        category: {
          connect: { id: categoryId },
        },
      },
    });

    res.json(updatedOption);
  } catch (error) {
    console.error('Error al actualizar opción:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};

// ✅ Eliminar una opción
const deleteOption = async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.option.delete({
      where: { id: parseInt(id) },
    });

    res.json({ message: 'Opción eliminada correctamente' });
  } catch (error) {
    console.error('Error al eliminar opción:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};

// ✅ Exportar correctamente
module.exports = {
  getActiveOptions,
  createOption,
  updateOption,
  deleteOption
};
