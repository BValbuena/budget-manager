const express = require('express');
const router = express.Router();
const optionController = require('../controllers/option.controller');
const { authenticateToken, authorizeRoles } = require('../middlewares/auth');

// Obtener solo opciones activas (público)
router.get('/', optionController.getActiveOptions);

// Crear nueva opción (solo admin)
router.post('/', authenticateToken, authorizeRoles('admin'), optionController.createOption);

// Actualizar opción existente (solo admin)
router.put('/:id', authenticateToken, authorizeRoles('admin'), optionController.updateOption);

// Eliminar opción (solo admin)
router.delete('/:id', authenticateToken, authorizeRoles('admin'), optionController.deleteOption);

module.exports = router;
